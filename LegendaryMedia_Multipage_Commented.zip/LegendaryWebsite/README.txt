LEGENDARY MEDIA MULTI-PAGE WEBSITE

FILES
- index.html: homepage
- about.html: about page and founder portrait
- services.html: separate services information
- bookings.html: date/time/service booking request form
- contact.html: contact enquiry form
- css/style.css: shared site design and responsive layout
- js/script.js: menu, theme buttons, chatbot and booking-form helpers
- images/: logo and supplied brand logos/founder portrait

HOW TO RUN
Open index.html in a browser, or use VS Code Live Server.

EDIT BEFORE PUBLISHING
1. Replace the sample email hello@legendarymedia.com with the verified company email if different.
2. Replace the placeholder phone number and office location.
3. The brand names/logos are illustrative client assets; ensure you have permission and that they represent real clients before publishing.
4. The booking and contact forms currently use FormSubmit. FormSubmit needs a one-time email activation. Test submissions before launch.
5. The booking form sends the chosen date/time/service to the business email as a request. It does not itself reserve calendar availability. Customer autoresponse may need to be enabled/configured with the email-form provider. Until the company replies, the booking is NOT confirmed.
6. Chat is a small scripted demo, not a live AI chatbot.
7. Package prices are example content—verify currency, prices, and inclusions.

HTML/CSS/JS comments are included to explain the project for beginners.
