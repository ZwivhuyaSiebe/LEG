// ============================================================
// LEGENDARY MEDIA - SHARED JAVASCRIPT
// This script runs on each page and safely checks if elements exist.
// ============================================================

// Find the hamburger button and the menu panel on the current page.
const menuToggle = document.getElementById('menuToggle');
const menuPanel = document.getElementById('menuPanel');


// Close the navigation panel and reset its accessibility attributes.
function closeMenu() {
  if (!menuToggle || !menuPanel) return;
  menuToggle.classList.remove('active');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuPanel.classList.remove('open');
  menuPanel.setAttribute('aria-hidden', 'true');
}


// When the menu button is clicked, toggle the menu between open and closed.
if (menuToggle && menuPanel) {
  menuToggle.addEventListener('click', () => {
    const isOpening = !menuPanel.classList.contains('open');
    menuToggle.classList.toggle('active', isOpening);
    menuToggle.setAttribute('aria-expanded', String(isOpening));
    menuPanel.classList.toggle('open', isOpening);
    menuPanel.setAttribute('aria-hidden', String(!isOpening));
  });
  // Close the menu after a navigation link is clicked.
  menuPanel.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
}


// Escape key closes the navigation and chat window if either is open.
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    closeMenu();
    const chatBox = document.getElementById('chatBox');
    if (chatBox) chatBox.hidden = true;
  }
});


// Grayscale button: toggles a black-and-white filter on the whole page.
const grayToggle = document.getElementById('grayToggle');
if (grayToggle) {
  grayToggle.addEventListener('click', () => {
    const enabled = document.body.classList.toggle('gray-mode');
    grayToggle.setAttribute('aria-pressed', String(enabled));
    grayToggle.querySelector('span').textContent = `BLACK & WHITE: ${enabled ? 'ON' : 'OFF'}`;
  });
}


// Theme button: toggles the CSS light-mode class and changes the button label.
const lightToggle = document.getElementById('lightToggle');
if (lightToggle) {
  lightToggle.addEventListener('click', () => {
    const enabled = document.body.classList.toggle('light-mode');
    lightToggle.setAttribute('aria-pressed', String(enabled));
    lightToggle.querySelector('span').textContent = enabled ? 'DARK MODE' : 'LIGHT MODE';
  });
}


// Booking form: read URL parameters and preselect a service or plan if requested.
const bookingService = document.getElementById('bookingService');
if (bookingService) {
  const params = new URLSearchParams(window.location.search);
  const serviceFromLink = params.get('service') || params.get('plan');
  if (serviceFromLink) {
    const matchingOption = Array.from(bookingService.options).find(option =>
      option.text.toLowerCase().includes(serviceFromLink.toLowerCase())
    );
    if (matchingOption) bookingService.value = matchingOption.value;
  }
  // Prevent booking dates in the past by setting today's date as the minimum.
  const dateField = document.getElementById('bookingDate');
  if (dateField) {
    const today = new Date();
    const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
      .toISOString().slice(0, 10);
    dateField.min = localToday;
  }
}


// Demo chatbot only (not connected to a live AI or company database).
const chatBox = document.getElementById('chatBox');
const chatLaunch = document.getElementById('chatLaunch');
const chatBody = document.getElementById('chatBody');
if (chatBox && chatLaunch && chatBody) {
  // Show or hide chat when its floating button is clicked.
  chatLaunch.addEventListener('click', () => { chatBox.hidden = !chatBox.hidden; });
  const closeChat = document.getElementById('chatClose');
  if (closeChat) closeChat.addEventListener('click', () => { chatBox.hidden = true; });

  // Add a new chat bubble; 'who' determines whether it's user or bot style.
  function addMessage(message, who = 'bot') {
    const bubble = document.createElement('div');
    bubble.className = who === 'user' ? 'user-msg' : 'bot-msg';
    bubble.textContent = message; // textContent avoids interpreting input as HTML.
    chatBody.appendChild(bubble);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  // Small keyword-based responses for common questions.
  function getReply(message) {
    const text = message.toLowerCase();
    if (text.includes('service')) return 'We offer traffic acquisition, booking and pricing optimisation, and customer retention. See the Services page for more details.';
    if (text.includes('book') || text.includes('reservation') || text.includes('date')) return 'Use our Bookings page to request a date and time. We will need to confirm the appointment with you.';
    if (text.includes('contact') || text.includes('email')) return 'Email hello@legendarymedia.com or visit our Contact page. Please verify this address before launch.';
    if (text.includes('price') || text.includes('cost')) return 'Our example packages are Starter Growth, Hospitality Pro and Legendary Partner. Visit the Home page for sample pricing; confirm prices before publishing.';
    return 'Thanks for your message! I can help point you to Services, Bookings or Contact. Use the booking form for a consultation request.';
  }


  // Quick-action buttons add the selected topic and an automatic reply.
  document.querySelectorAll('[data-chat]').forEach(button => {
    button.addEventListener('click', () => {
      addMessage(button.textContent, 'user');
      addMessage(getReply(button.dataset.chat));
    });
  });


  // Chat form: display the typed message and respond with our scripted reply.
  const chatForm = document.getElementById('chatForm');
  if (chatForm) {
    chatForm.addEventListener('submit', event => {
      event.preventDefault(); // Keep the chat from refreshing the page.
      const input = document.getElementById('chatInput');
      const message = input.value.trim();
      if (!message) return; // Ignore empty messages.
      addMessage(message, 'user');
      addMessage(getReply(message));
      input.value = ''; // Clear the input after sending.
    });
  }
}
